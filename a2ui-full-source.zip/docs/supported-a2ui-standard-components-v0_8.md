# 本仓库 Renderer 支持的 A2UI 标准组件（v0_8 对照）

本文档以 [specification/v0_8/json/standard_catalog_definition.json](../specification/v0_8/json/standard_catalog_definition.json) 中的 **Standard Catalog** 为基准，说明当前 **[packages/a2ui-react/src/components](../packages/a2ui-react/src/components)** 已注册到 `renderMap` / `createRenderMap` 的组件，以及在 **[a2ui-core](../packages/a2ui-core)** 解析与渲染管线中的实际行为。

更完整的协议语义见 [specification/v0_8/docs/a2ui_protocol.md](../specification/v0_8/docs/a2ui_protocol.md)（尤其 **§4.2 BoundValue**）。

---

## 1. BoundValue 与 `literalString`

协议中，可绑定字段使用 **BoundValue**：可为仅字面量、仅 `path`，或 **两者兼有**。若同时提供 `path` 与 `literalString`，客户端应在 **`path` 能解析到值时优先使用模型值**；否则使用 `literalString` 作为回退（协议示例中常见如 `"Guest"` 等）。

- **`literalString` 的值由发送方任意填写**，协议**没有**定义 `empty`、`(empty)` 等保留字或特殊含义。
- 本仓库 mock 中出现的 `"(empty)"`、`"(loading)"` 等仅为**示例占位文案**，与协议枚举无关。

**本仓库运行时解析（a2ui-core `renderComponent`）**：

- 对 **`Text`** 的 `text`：在渲染前将 BoundValue 解析为**单一字符串**（`resolveBoundText`），再交给 React 组件显示。
- **`List` / `Row` / `Column` 的 `children.template`**：模板子树内 **`Text`** 的绑定在 **每项 item 作用域**上解析；其它组件若含 BoundValue，仍以当前实现为准（见下表）。
- 除上述路径外，**多数组件属性仍按 JSON 原样传入**，由 React 层自行读取 `literalString` / `path` 字符串（见下表「实现差异」）。

---

## 2. 已实现的 Standard Catalog 组件一览

下列组件名与 **standard catalog 的 `components` 键名**一致，且已在 [packages/a2ui-react/src/components/index.ts](../packages/a2ui-react/src/components/index.ts) 注册。

| 组件 | 标准 catalog 要求摘要 | 本仓库 React 实现要点 | 与标准 / 解析管线差异 |
|------|------------------------|------------------------|-------------------------|
| **Text** | `text`: BoundValue（`literalString` \| `path`）；可选 `usageHint`: h1–h5, caption, body | [Text.tsx](../packages/a2ui-react/src/components/Text.tsx)：`usageHint` 映射样式；展示字符串 | **a2ui-core 对 `text` 做数据绑定解析**；若仅字面量未走解析，组件侧仍用 `literalString \|\| path` 作兜底显示（与完全解析后的单字符串行为需保持一致时，应依赖 parser 传入已解析的 `literalString`）。 |
| **Image** | `url`: BoundValue；可选 `fit`，`usageHint` | [Image.tsx](../packages/a2ui-react/src/components/Image.tsx)：`source.uri`、`alt`、`width`、`height` | **与标准字段名不一致**：标准定义为 **`url`**（BoundValue），本实现使用 **`source.uri`**（见 [image-demo.json](../packages/a2ui-core/mock/image-demo.json)）。**`url` 的 path 解析未在 parser 中统一处理**，需依赖传入已解析的 `source.uri` 或扩展 parser。 |
| **Icon** | `name`: BoundValue；`literalString` 在 schema 中可枚举图标名 | [Icon.tsx](../packages/a2ui-react/src/components/Icon.tsx)：`name` 字符串、`size`、`color`，直接渲染文本占位 | **未在 parser 中解析 `name` 的 path**；mock 常用 emoji 字符串。与标准「图标名枚举」一致程度取决于传入的 `name` 字符串。 |
| **Button** | `child`（子组件 id）、`primary`、`action`（必填 `name` 等） | [Button.tsx](../packages/a2ui-react/src/components/Button.tsx)：`text` BoundValue、`variant`、`size`、`disabled` | **与标准结构差异较大**：标准以 **`child` 引用 Text 组件**且 **`action` 必填**；本实现为 **内联 `text`** + 样式 variant，**无 `action` 协议模型**。示例见 [button-demo.json](../packages/a2ui-core/mock/button-demo.json)。 |
| **Column** | `children`：`explicitList` 或 `template`；`distribution`、`alignment` | [Column.tsx](../packages/a2ui-react/src/components/Column.tsx)：flex 列布局 | **template 列表**：由 **a2ui-core `treeBuild`** 展开，子项 **synthetic id** 规则为 `` `${parentId}__tpl__${templateComponentId}__${index}` ``。 |
| **Row** | 同上（主轴为水平） | [Row.tsx](../packages/a2ui-react/src/components/Row.tsx) | 同上。 |
| **List** | 同上；`direction` vertical/horizontal；`alignment` | [List.tsx](../packages/a2ui-react/src/components/List.tsx) | 同上。 |
| **Card** | **`child`**：单个子组件 id | [Card.tsx](../packages/a2ui-react/src/components/Card.tsx)：`title`、`subtitle`（BoundValue）、`children`、`elevation` | **与标准差异较大**：标准仅 **`child`**；本实现为 **标题/副标题 + `children.explicitList`** 等（见 [card-demo.json](../packages/a2ui-core/mock/card-demo.json)）。**`title`/`subtitle` 的 path 未在 parser 中统一解析**，组件内用 `literalString \|\| path` 显示。 |

---

## 3. 标准 catalog 中有、但本仓库未提供 Renderer 的组件（节选）

以下仅作对照，**当前 `renderMap` 未注册**，传入 `surfaceUpdate` 时会在 parser 中触发「未注册」类错误或未按标准渲染：

- `Video`、`AudioPlayer`、`Tabs`、`Divider`、`Modal`、`CheckBox`、`TextField`、`Slider`、`DateTimeInput`、`MultipleChoice`、`ShortAnswer`、`Chip`、`Drawer`、`Carousel` 等（以 `standard_catalog_definition.json` 中 `components` 全集为准）。

---

## 4. 容器与 `children`（协议对齐部分）

对 **Column / Row / List**，协议定义：

- `children.explicitList`: `string[]`，组件 id 列表。
- `children.template`: `{ componentId, dataBinding }`，由数据模型路径驱动列表渲染。

本仓库 **a2ui-core** 已支持：

- `explicitList` 与 **template**（与 `explicitList` 互斥时以 `explicitList` 优先）。
- template 展开时，子实例 **id** 唯一，且 **Text** 绑定在 **item** 上解析。

---

## 5. 小结

- **协议层面**：`literalString` 与 `path` 为 **BoundValue** 的字段；**不存在**协议级别的 `"empty"` 语义。
- **本仓库**：以 **standard catalog** 为参考，**Text / 容器 template 绑定** 与协议较接近；**Button、Card、Image** 等与 **standard_catalog_definition.json** 的字段形状存在**有意或历史原因**的差异，实际以 **组件 TSX + mock JSON** 为准。

若需严格校验「仅标准 JSON Schema」，应对 `surfaceUpdate.components` 使用 **validator**（见 `specification/v0_8/eval/src/validator.ts`）并单独维护「严格模式」payload；与当前 React 渲染器并存时，需做 **字段映射层**（adapter）。
